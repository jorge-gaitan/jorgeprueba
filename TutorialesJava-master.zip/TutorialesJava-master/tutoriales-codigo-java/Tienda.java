package paquete;

public class Tienda {

	 String nombre;
	 String color;
	 int codigo;
}
