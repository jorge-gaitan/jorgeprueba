package paquete;

//Creado Por: Jean Bernuy

public class Objetos {

	public static void main(String[] args) {
		
		//varibles
		
		/*String nombre="bicicleta";
		String color="azul";
		int codigo= 1001;
		
		String nombre2="moto";
		String color2="negro";
		int codigo2=1002;
       */
		
		Tienda t;
		t=new Tienda();
		t.nombre="bicicleta";
		t.color="azul";
		t.codigo=1001;
		
		Tienda t2= new Tienda();
		t2.nombre="moto";
		t2.color="rojo";
		t2.codigo=1002;
		
		Tienda t3= new Tienda();
		t3.nombre=" jose";
		
	}

}
