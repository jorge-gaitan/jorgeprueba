package paquete;

public class HolaMundo {

	/**
	 * Creado Por: Jean Bernuy
	 */
	public static void main(String[] args) {
		
		/* Tipo de variables
		String texto="";
		double var;
		int var1;
		char var2;
		boolean var3;
		long var4;
		short var5;
		*/

        System.out.println("Hola Mundo..." );
        
	
	}

}
